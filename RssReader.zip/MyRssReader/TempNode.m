//
//  TempNode.m
//  MyRssReader
//
//  Created by Huyns89 on 5/30/14.
//  Copyright (c) 2014 Huyns. All rights reserved.
//

#import "TempNode.h"

@implementation TempNode
@synthesize bookmarkStatus, isAddedToBoomark, nodeImage, nodeSource, nodeTitle, nodeType, nodeUrl;
@end
