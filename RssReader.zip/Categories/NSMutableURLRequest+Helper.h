//
//  NSMutableURLRequest+Helper.h
//  MyRssReader
//
//  Created by Huyns89 on 5/28/14.
//  Copyright (c) 2014 Huyns. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableURLRequest (Helper)

-(id) initWithMethod:(NSString *) method andUrl:(NSString *) url;

@end
