//
//  UIViewController+Helper.h
//  MyRssReader
//
//  Created by Huyns89 on 5/26/14.
//  Copyright (c) 2014 Huyns. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Helper)
+(id) initWithNibName;
-(BOOL) isInternetConnected;
@end
