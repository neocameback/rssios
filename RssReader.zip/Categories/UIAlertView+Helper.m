//
//  UIAlertView+Helper.m
//  MyRssReader
//
//  Created by Huyns89 on 5/27/14.
//  Copyright (c) 2014 Huyns. All rights reserved.
//

#import "UIAlertView+Helper.h"

@implementation UIAlertView (Helper)

@end
